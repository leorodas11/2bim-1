﻿Public Class dinero

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b, c, d, g, f As Integer
        a = TextBox2.Text
        b = TextBox3.Text
        c = TextBox4.Text
        d = TextBox8.Text
        g = TextBox9.Text
        f = TextBox7.Text
        TextBox1.Text = a + b + c + d + g + f


    End Sub
End Class