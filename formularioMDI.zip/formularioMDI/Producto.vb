﻿Public Class Producto
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b, c, d, g As Integer
        a = TextBox1.Text
        b = TextBox2.Text
        c = TextBox3.Text
        d = TextBox4.Text
        g = TextBox5.Text

        TextBox6.Text = a + b + c + d + g

    End Sub
End Class